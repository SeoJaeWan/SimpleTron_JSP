package db;

import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class JdbcUtil {

	public static Connection getConnection(){
		Connection con=null;
		String driverName="com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://218.157.244.7:8880/micom";
		String id = "CP";
		String pwd ="password";
		try {
			Class.forName(driverName);		
			
		}catch(ClassNotFoundException e){

			e.printStackTrace();

		}
		try {
			con = DriverManager.getConnection(url,id,pwd);
		} catch (SQLException e) {
			// TODO �ڵ� ������ catch ����
			e.printStackTrace();
		}
		return con;
	}
	
	public static void close(Connection con){
		
		try {
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void close(Statement stmt){
		
		try {
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void close(ResultSet rs){
		
		try {
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void commit(Connection con){
		
		try {
			con.commit();
			System.out.println("commit success");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void rollback(Connection con){
		
		try {
			con.rollback();
			System.out.println("rollback success");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
